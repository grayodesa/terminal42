<div class="tve_cpanel_sec" style="padding-right: 14px;">
	<div class="tve_option_separator tve_dropdown_submenu tve_drop_style">
		<div class="tve_ed_btn tve_btn_text" style="display: block;">
			<span id="sub_02" class="tve_caret tve_icm tve_right tve_sub_btn tve_expanded" style="margin-top: -3px; margin-left: 4px;"></span>
			<span class="tve_expanded"><?php echo __( "Thrive Lightbox", "thrive-cb" ) ?></span>
			<span class="tve_collapsed tve_icm tve_left tve-ic-lp"></span>
			<div class="tve_clear"></div>
		</div>
		<div class="tve_sub_btn">
			<div class="tve_sub" style="bottom: auto;top: 30px;width: 159px;">
				<ul>
					<li class="tve_click" data-ctrl="controls.click.show_elem_menu" data-element-selector=".tve_p_lb_control">
						<?php echo __( "Lightbox Settings", "thrive-cb" ) ?>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<div class="tve_clear"></div>
</div>
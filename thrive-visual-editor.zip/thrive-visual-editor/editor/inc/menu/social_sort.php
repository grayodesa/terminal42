<div class="tve_ed_btn tve_btn_text tve_right tve_click" data-ctrl="function:social.saveSortable">
	<div class="tve_icm tve-ic-checkmark tve_left" style="color: #47bb28"></div>
	<?php echo __( "Save and Close", "thrive-cb" ) ?>
</div>
<div class="tve_ed_btn tve_btn_text tve_right tve_click" data-ctrl="function:social.closeSortable">
	<div class="tve_icm tve-ic-cancel-circle tve_left" style="color: #bf2718"></div>
	<?php echo __( "Close", "thrive-cb" ) ?>
</div>

<span class="tve_options_headline"><span class="tve_icm tve-ic-move"></span><?php echo __( "Guarantee element options", "thrive-cb" ) ?></span>
<ul class="tve_menu">
	<?php $has_custom_colors = true;
	$extra_attr              = 'data-multiple-hide';
	include dirname( __FILE__ ) . '/_custom_colors.php' ?>
	<?php include dirname( __FILE__ ) . '/_margin.php' ?>
</ul>
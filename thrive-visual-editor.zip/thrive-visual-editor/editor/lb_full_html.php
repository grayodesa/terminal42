<h4><?php echo __( "Edit the HTML of your Page", "thrive-cb" ) ?></h4>
<hr class="tve_lightbox_line"/>
<p><?php echo __( 'When you click the "Save" button, your changes will be loaded into the page.', 'thrive-cb' ) ?></p>
<input type="hidden" name="tve_lb_type" value="tve_full_html">
<textarea name="tve_full_html" class="tve_lightbox_textarea tve_textarea_large">
<?php echo __( "Insert your HTML content here.", 'thrive-cb' ) ?>
</textarea>

<h4><?php echo __( "Insert your Google Map Embed Code", "thrive-cb" ) ?></h4>
<hr class="tve_lightbox_line"/>
<p><?php echo __( 'When you click the "Save" button, your map will be loaded onto the page', "thrive-cb" ) ?></p>
<input type="hidden" name="tve_lb_type" value="tve_google_map">
<textarea name="tve_embed_code" class="tve_lightbox_textarea tve_textarea_large">
<?php echo __( "Replace this with your Google Map embed code.", "thrive-cb" ) ?>
</textarea>

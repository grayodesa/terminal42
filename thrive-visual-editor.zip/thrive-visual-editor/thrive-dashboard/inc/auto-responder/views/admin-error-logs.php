<div class="wrap">
	<h2><?php echo __( "Thrive API Connections - error logs", TVE_DASH_TRANSLATE_DOMAIN ) ?></h2>
	<?php $table->display() ?>
</div>
<a class="button button-primary button-large" href="<?php echo admin_url( "admin.php?page=tve_dash_api_connect" ) ?>"><?php echo __( "Back to API Connections", TVE_DASH_TRANSLATE_DOMAIN ) ?></a>

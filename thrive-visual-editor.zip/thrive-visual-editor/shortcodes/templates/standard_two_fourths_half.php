<?php /*
<div class="thrv_wrapper thrv_columns">
    <div class="tve_colm tve_foc"><p>Column 1</p></div>
    <div class="tve_colm tve_foc"><p>Column 2</p></div>
    <div class="tve_colm tve_twc tve_lst"><p>Column 3</p></div>
</div>
 */ ?>
<div class="thrv_wrapper thrv_columns">
	<div class="tve_colm tve_foc tve_df tve_fft"><p>Column 1</p></div>
	<div class="tve_colm tve_foc tve_df tve_fft"><p>Column 2</p></div>
	<div class="tve_colm tve_twc tve_lst"><p>Column 3</p></div>
</div>


<div class="thrv_wrapper thrv_columns tve_clearfix">
	<div class="tve_colm tve_foc"><p>Column 1</p></div>
	<div class="tve_colm tve_foc"><p>Column 2</p></div>
	<div class="tve_colm tve_foc"><p>Column 3</p></div>
	<div class="tve_colm tve_foc tve_lst"><p>Column 4</p></div>
</div>
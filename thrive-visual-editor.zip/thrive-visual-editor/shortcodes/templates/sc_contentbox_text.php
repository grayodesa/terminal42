<div class="thrv_wrapper thrv_contentbox_shortcode" data-tve-style="symbol">
	<div class="tve_cb tve_cb_symbol <?php echo $_POST['colour'] ?>">
		<div class="thrv_wrapper thrv_icon thrv_cb_text aligncenter tve_no_drag tve_no_icons" style="font-size: 40px;">
			<span class="tve_sc_text tve_sc_icon">1</span>
		</div>
		<div class="tve_cb_cnt">
			<p><span class="bold_text">MAIN LABEL</span></p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae, officia? </p>
		</div>
	</div>
</div>
<div class="thrv_wrapper thrv_columns tve_clearfix">
	<div class="tve_colm tve_tth"><p>Column 1</p></div>
	<div class="tve_colm tve_oth tve_lst"><p>Column 2</p></div>
</div>
<div class="thrv_wrapper thrv_countdown_timer tve_countdown_timer_evergreen tve_cd_timer_plain tve_clearfix init_done <?php echo $_POST['colour']; ?>"
     data-day="0"
     data-hour="2"
     data-min="0"
     data-sec="0"
     data-id="<?php echo uniqid( "evergreen_" ) ?>"
     data-expday="0"
     data-exphour="1"
>
	<div class="sc_timer_content tve_clearfix">
		<div class="tve_t_day tve_t_part">
			<div class="t-digits"></div>
			<div class="t-caption">Days</div>
		</div>
		<div class="tve_t_hour tve_t_part">
			<div class="t-digits"></div>
			<div class="t-caption">Hours</div>
		</div>
		<div class="tve_t_min tve_t_part">
			<div class="t-digits"></div>
			<div class="t-caption">Minutes</div>
		</div>
		<div class="tve_t_sec tve_t_part">
			<div class="t-digits"></div>
			<div class="t-caption">Seconds</div>
		</div>
		<div class="tve_t_text"></div>
	</div>
</div>
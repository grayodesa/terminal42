<div class="thrv_wrapper thrv_page_section" data-tve-style="1">
	<div class="out" style="background-color: #EAEAEA">
		<div class="in darkSec">
			<div class="cck tve_clearfix">
				<p>This is a page section</p>
			</div>
		</div>
	</div>
</div>
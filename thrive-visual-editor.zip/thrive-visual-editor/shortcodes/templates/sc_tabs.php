<div class="thrv_wrapper thrv_tabs_shortcode">
	<div class="tve_scT<?php echo empty( $_POST['vtabs'] ) ? '' : ' tve_vtabs' ?> <?php echo $_POST['colour']; ?>">
		<ul class="tve_clearfix">
			<li class="tve_tS"><span class="tve_scTC1">First tab</span></li>
			<li><span class="tve_scTC2">Second tab</span></li>
			<li><span class="tve_scTC3">Third tab</span></li>
		</ul>
		<div class="tve_scTC tve_scTC1" style="display: block">
			<p>Tab 1</p>
		</div>
		<div class="tve_scTC tve_scTC2">
			<p>Tab 2</p>
		</div>
		<div class="tve_scTC tve_scTC3">
			<p>Tab 3</p>
		</div>
	</div>
</div>
<div class="thrivecb light red thrv_wrapper">
	<div class="dark shn red"><h4 class="">Headline Goes Here</h4></div>
	<div class="shn"><p>Enter your text here.</p></div>
</div>
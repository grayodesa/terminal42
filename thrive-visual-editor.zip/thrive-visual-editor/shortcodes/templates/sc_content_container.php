<div class="thrv_wrapper thrv_content_container_shortcode">
	<div class="tve_clear"></div>
	<div class="tve_left tve_content_inner" style="width: 300px;min-width:50px; min-height: 2em;">
		<p>Your content here...</p>
	</div>
	<div class="tve_clear"></div>
</div>
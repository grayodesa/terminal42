<div class="tve_wp_shortcode code_placeholder thrv_wrapper">
	<a class="tve_click tve_green_button clearfix" id="lb_shortcode"
	   data-ctrl="controls.lb_open" data-wpapi="lb_shortcode">
		<i class="tve_icm tve-ic-code"></i>
		<span>Insert WordPress Content</span>
	</a>
</div>
<div class="fwi thrv_wrapper image_placeholder code_placeholder">
	<a class="upload_image tve_green_button clearfix" href="#" target="_self">
		<i class="tve_icm tve-ic-upload"></i>
		<span>Add Media</span>
	</a>
</div>
<div class="thrv_wrapper thrv_contentbox_shortcode" data-tve-style="symbol">
	<div class="tve_cb tve_cb_symbol <?php echo $_POST['colour'] ?>">
		<?php $cb_icon = true;
		include dirname( __FILE__ ) . '/sc_icon.php' ?>
		<div class="tve_cb_cnt">
			<p><span class="bold_text">MAIN LABEL</span></p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae, officia? </p>
		</div>
	</div>
</div>
<div class="thrv_wrapper thrv_cc_icons">
	<div class="thrv_cc_wrapper">
		<span class="tve_cc_amex tve_cc_logo tve_no_edit"></span>
		<span class="tve_cc_discover tve_cc_logo tve_no_edit"></span>
		<span class="tve_cc_mc tve_cc_logo tve_no_edit"></span>
		<span class="tve_cc_visa tve_cc_logo tve_no_edit"></span>
		<span class="tve_cc_paypal tve_cc_logo tve_no_edit"></span>
	</div>
</div>
<div class="image_placeholder thrv_wrapper">
	<a class="upload_image tve_green_button clearfix" href="#" target="_self">
		<i class="tve_icm tve-ic-upload"></i>
		<span>Add Media</span>
	</a>
</div>

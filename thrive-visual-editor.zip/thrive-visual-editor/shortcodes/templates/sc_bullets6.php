<div class="thrv_wrapper thrv_bullets_shortcode">
	<ul class="tve_ul tve_ul6 <?php echo $_POST['colour']; ?>">
		<li>li li li</li>
		<li>li li li</li>
	</ul>
</div>